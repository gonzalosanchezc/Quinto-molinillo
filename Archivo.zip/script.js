document.querySelector(".hamburguer-menu").addEventListener("click", () => {
    document.querySelector(".body").classList.toggle("change");
})